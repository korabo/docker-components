<?php

class plugin_info{
    const PLUGIN_CODE       = "EcTenchoApi";
    const PLUGIN_NAME       = "EC店長連携プラグイン";
    const PLUGIN_VERSION    = "0.1.0a";
    const COMPLIANT_VERSION = "2.13.5";
    const AUTHOR            = "ブランジスタソリューション";
    const DESCRIPTION       = "EC店長連携用プラグイン";
    const CLASS_NAME        = "EcTenchoApi";

}

?>
